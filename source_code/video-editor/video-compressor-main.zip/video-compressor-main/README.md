## Bepto Video Compressor

An elegant, simple video compressor.

### Features

- Compress multiple videos in a queue system.
- Compress videos to any file size.
- Remove audio from videos.
- H.265 codec option.

### Preview

![Preview](https://github.com/cheezos/video-compressor/blob/main/preview.png)
